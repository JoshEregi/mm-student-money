# M&M Student Money — Phase 2 starter

Student/school finance app starter for Kenya. Includes the M&M UI, Capacitor Android configuration, Express API, PostgreSQL schema, and a first-pass server-side M-Pesa Daraja STK Push scaffold.

Start with `docs/BUILD_AND_SECURITY.md`.

**This is not a finished production finance service and no APK is included.** The UI is not yet connected to the API. Real payment integration requires Daraja sandbox credentials, a public HTTPS callback URL, provider setup, testing, and security review.
