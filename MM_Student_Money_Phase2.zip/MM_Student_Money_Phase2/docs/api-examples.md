# API quick examples

Register a student (development only):
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"fullName":"Demo Student","email":"student@example.test","password":"Use-A-Long-Unique-Test-Password","role":"student"}'
```

Login:
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"student@example.test","password":"Use-A-Long-Unique-Test-Password"}'
```

Use the returned token as `Authorization: Bearer TOKEN` for authenticated routes. Use fake data only.
