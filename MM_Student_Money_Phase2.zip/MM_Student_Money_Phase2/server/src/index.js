import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { pool } from "./db.js";
import { requireAuth, requireRole } from "./auth.js";
import { startMpesaStkPush } from "./mpesa.js";

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") || false }));
app.use(express.json({ limit: "100kb" }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));
app.use("/api/payments", rateLimit({ windowMs: 60 * 1000, limit: 10 }));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "M&M API", mode: process.env.NODE_ENV || "development" }));

const registerSchema = z.object({
  fullName: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(200),
  password: z.string().min(10).max(100),
  role: z.enum(["student", "parent", "school_admin"]).default("student"),
  schoolId: z.string().uuid().optional()
});
app.post("/api/auth/register", async (req, res, next) => {
  try {
    const data = registerSchema.parse(req.body);
    // Public registration cannot create privileged platform administrators.
    if (data.role === "school_admin" && !data.schoolId) {
      return res.status(400).json({ error: "School admin registration requires an approved school invitation flow." });
    }
    const hash = await bcrypt.hash(data.password, 12);
    const result = await pool.query(
      `INSERT INTO users (full_name,email,password_hash,role,school_id)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id,full_name,email,role,school_id,created_at`,
      [data.fullName, data.email.toLowerCase(), hash, data.role, data.schoolId || null]
    );
    return res.status(201).json({ user: result.rows[0], message: "Account created. Configure email verification before production." });
  } catch (err) {
    if (err?.code === "23505") return res.status(409).json({ error: "Email already registered" });
    if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid input", details: err.issues });
    next(err);
  }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const schema = z.object({ email: z.string().email(), password: z.string().min(1) });
    const data = schema.parse(req.body);
    const result = await pool.query(
      "SELECT id,full_name,email,password_hash,role,school_id,active FROM users WHERE email=$1",
      [data.email.toLowerCase()]
    );
    const user = result.rows[0];
    if (!user || !user.active || !(await bcrypt.compare(data.password, user.password_hash))) {
      return res.status(401).json({ error: "Email or password is incorrect" });
    }
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
      return res.status(500).json({ error: "Server authentication secret is not configured safely" });
    }
    const token = jwt.sign({ sub: user.id, role: user.role, schoolId: user.school_id }, process.env.JWT_SECRET, { expiresIn: "2h", issuer: "mm-student-money" });
    return res.json({ token, expiresIn: 7200, user: { id: user.id, fullName: user.full_name, email: user.email, role: user.role, schoolId: user.school_id } });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid input" });
    next(err);
  }
});

app.get("/api/me", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query("SELECT id,full_name,email,role,school_id,created_at FROM users WHERE id=$1 AND active=true", [req.user.sub]);
    if (!result.rowCount) return res.status(404).json({ error: "User not found" });
    res.json({ user: result.rows[0] });
  } catch (err) { next(err); }
});

app.get("/api/transactions", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id,kind,description,amount_kes,category,status,created_at FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 200",
      [req.user.sub]
    );
    res.json({ transactions: result.rows });
  } catch (err) { next(err); }
});

app.post("/api/transactions", requireAuth, async (req, res, next) => {
  try {
    const schema = z.object({
      kind: z.enum(["income", "expense"]),
      description: z.string().trim().min(1).max(120),
      amountKes: z.number().int().positive().max(100000000),
      category: z.string().trim().min(1).max(60)
    });
    const d = schema.parse(req.body);
    const result = await pool.query(
      `INSERT INTO transactions(user_id,kind,description,amount_kes,category,status)
       VALUES($1,$2,$3,$4,$5,'recorded')
       RETURNING id,kind,description,amount_kes,category,status,created_at`,
      [req.user.sub, d.kind, d.description, d.amountKes, d.category]
    );
    res.status(201).json({ transaction: result.rows[0] });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid input", details: err.issues });
    next(err);
  }
});

app.get("/api/admin/summary", requireAuth, requireRole("platform_admin", "school_admin"), async (req, res, next) => {
  try {
    const params = [];
    let where = "";
    if (req.user.role === "school_admin") {
      params.push(req.user.schoolId);
      where = " WHERE school_id=$1";
    }
    const users = await pool.query(`SELECT role,COUNT(*)::int AS count FROM users${where} GROUP BY role`, params);
    res.json({ usersByRole: users.rows, note: "Administrative actions must be audited before production." });
  } catch (err) { next(err); }
});

// Payment request creates a pending record only after the provider flow is configured.
// Never trust the mobile app to declare a payment successful.
app.post("/api/payments/mpesa/stk-push", requireAuth, async (req, res, next) => {
  try {
    const schema = z.object({
      phone: z.string().regex(/^254[17]\\d{8}$/),
      amountKes: z.number().int().min(1).max(150000),
      description: z.string().trim().min(1).max(100)
    });
    const d = schema.parse(req.body);
    const record = await pool.query(
      `INSERT INTO payment_intents(user_id,provider,phone_e164,amount_kes,description,status)
       VALUES($1,'mpesa',$2,$3,$4,'created') RETURNING id,status`,
      [req.user.sub, d.phone, d.amountKes, d.description]
    );
    const intent = record.rows[0];
    const result = await startMpesaStkPush({ ...d, accountReference: intent.id });
    if (!result.configured) {
      return res.status(501).json({
        error: "M-Pesa is not configured yet. Payment intent was saved but no money was requested.",
        paymentId: intent.id,
        status: "created",
        required: ["Daraja sandbox credentials", "public HTTPS callback URL", "backend environment setup"]
      });
    }
    await pool.query(
      "UPDATE payment_intents SET merchant_request_id=$1,checkout_request_id=$2,status='pending' WHERE id=$3",
      [result.MerchantRequestID, result.CheckoutRequestID, intent.id]
    );
    res.status(202).json({ paymentId: intent.id, status: "pending", message: "Check the phone for the M-Pesa prompt." });
  } catch (err) {
    if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid payment details", details: err.issues });
    next(err);
  }
});

// Configure the provider callback URL to this endpoint. Verify signatures/provider data
// against the current Daraja specification before production; do not expose this as trusted
// until validation, idempotency and reconciliation have been implemented and tested.
app.post("/api/payments/mpesa/callback", async (req, res, next) => {
  try {
    const callback = req.body?.Body?.stkCallback;
    if (!callback?.CheckoutRequestID || !callback?.MerchantRequestID) {
      return res.status(400).json({ ResultCode: 1, ResultDesc: "Invalid callback payload" });
    }
    const code = Number(callback.ResultCode);
    const metadata = callback.CallbackMetadata?.Item || [];
    const get = name => metadata.find(x => x.Name === name)?.Value ?? null;
    const receipt = get("MpesaReceiptNumber");
    const amount = get("Amount");
    const phone = get("PhoneNumber");
    await pool.query(
      `UPDATE payment_intents SET status=$1,provider_result_code=$2,provider_result_desc=$3,
       mpesa_receipt_number=$4,provider_amount=$5,provider_phone=$6,callback_payload=$7,updated_at=now()
       WHERE checkout_request_id=$8`,
      [code === 0 ? "provider_success_unverified" : "failed", code, String(callback.ResultDesc || ""), receipt, amount, phone, JSON.stringify(req.body), callback.CheckoutRequestID]
    );
    res.json({ ResultCode: 0, ResultDesc: "Accepted for reconciliation" });
  } catch (err) { next(err); }
});

app.get("/api/payments/:id", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id,provider,amount_kes,description,status,mpesa_receipt_number,created_at,updated_at FROM payment_intents WHERE id=$1 AND user_id=$2",
      [req.params.id, req.user.sub]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Payment not found" });
    res.json({ payment: result.rows[0] });
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  console.error(err?.message || "Unhandled error");
  res.status(500).json({ error: "Unexpected server error" });
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`M&M API listening on port ${port}`));
