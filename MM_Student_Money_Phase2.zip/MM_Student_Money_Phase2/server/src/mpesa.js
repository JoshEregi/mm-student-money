import "dotenv/config";
import https from "node:https";
import { URLSearchParams } from "node:url";

const env = process.env.DARAJA_ENV || "sandbox";
const base = env === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

function postJson(url, headers, payload) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = Buffer.from(JSON.stringify(payload));
    const req = https.request(u, {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json", "Content-Length": body.length }
    }, response => {
      let data = "";
      response.setEncoding("utf8");
      response.on("data", chunk => data += chunk);
      response.on("end", () => {
        let parsed;
        try { parsed = JSON.parse(data); } catch { return reject(new Error("Unexpected response from payment provider")); }
        if (response.statusCode < 200 || response.statusCode >= 300) return reject(new Error(parsed.errorMessage || parsed.error || "Payment provider request failed"));
        resolve(parsed);
      });
    });
    req.on("error", reject);
    req.end(body);
  });
}

async function accessToken() {
  const key = process.env.DARAJA_CONSUMER_KEY;
  const secret = process.env.DARAJA_CONSUMER_SECRET;
  if (!key || !secret) return null;
  const auth = Buffer.from(`${key}:${secret}`).toString("base64");
  return new Promise((resolve, reject) => {
    const url = new URL(`${base}/oauth/v1/generate?grant_type=client_credentials`);
    https.get(url, { headers: { Authorization: `Basic ${auth}` } }, response => {
      let data = "";
      response.setEncoding("utf8");
      response.on("data", chunk => data += chunk);
      response.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          if (response.statusCode < 200 || response.statusCode >= 300 || !parsed.access_token) return reject(new Error("Could not obtain Daraja access token"));
          resolve(parsed.access_token);
        } catch { reject(new Error("Invalid Daraja OAuth response")); }
      });
    }).on("error", reject);
  });
}

export async function startMpesaStkPush({ phone, amountKes, description, accountReference }) {
  const required = ["DARAJA_CONSUMER_KEY", "DARAJA_CONSUMER_SECRET", "DARAJA_SHORTCODE", "DARAJA_PASSKEY", "DARAJA_CALLBACK_URL"];
  if (required.some(k => !process.env[k])) return { configured: false };
  const token = await accessToken();
  const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
  const shortcode = process.env.DARAJA_SHORTCODE;
  const password = Buffer.from(`${shortcode}${process.env.DARAJA_PASSKEY}${timestamp}`).toString("base64");
  const payload = {
    BusinessShortCode: shortcode,
    Password: password,
    Timestamp: timestamp,
    TransactionType: "CustomerPayBillOnline",
    Amount: amountKes,
    PartyA: phone,
    PartyB: shortcode,
    PhoneNumber: phone,
    CallBackURL: process.env.DARAJA_CALLBACK_URL,
    AccountReference: String(accountReference).slice(0, 12),
    TransactionDesc: description.slice(0, 13)
  };
  const response = await postJson(`${base}/mpesa/stkpush/v1/processrequest`, { Authorization: `Bearer ${token}` }, payload);
  return { configured: true, ...response };
}
