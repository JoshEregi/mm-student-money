CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS schools (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(160) NOT NULL,
  registration_code varchar(80) UNIQUE,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name varchar(100) NOT NULL,
  email varchar(200) NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role varchar(24) NOT NULL CHECK (role IN ('student','parent','school_admin','platform_admin')),
  school_id uuid REFERENCES schools(id),
  active boolean NOT NULL DEFAULT true,
  email_verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS users_school_idx ON users(school_id);

CREATE TABLE IF NOT EXISTS parent_student_links (
  parent_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  student_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  relationship varchar(40),
  approved_at timestamptz,
  PRIMARY KEY(parent_user_id, student_user_id)
);

CREATE TABLE IF NOT EXISTS budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month date NOT NULL,
  limit_kes bigint NOT NULL CHECK (limit_kes >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, month)
);

CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind varchar(16) NOT NULL CHECK (kind IN ('income','expense','school_fee','refund')),
  description varchar(120) NOT NULL,
  amount_kes bigint NOT NULL CHECK (amount_kes > 0),
  category varchar(60) NOT NULL,
  status varchar(24) NOT NULL DEFAULT 'recorded',
  payment_intent_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS transactions_user_created_idx ON transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS payment_intents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  provider varchar(20) NOT NULL CHECK (provider IN ('mpesa')),
  phone_e164 varchar(12) NOT NULL,
  amount_kes bigint NOT NULL CHECK (amount_kes > 0),
  description varchar(100) NOT NULL,
  status varchar(32) NOT NULL DEFAULT 'created',
  merchant_request_id text,
  checkout_request_id text UNIQUE,
  provider_result_code integer,
  provider_result_desc text,
  mpesa_receipt_number text,
  provider_amount numeric(12,2),
  provider_phone text,
  callback_payload jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS payment_intents_user_created_idx ON payment_intents(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid REFERENCES users(id),
  action varchar(100) NOT NULL,
  target_type varchar(80),
  target_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
